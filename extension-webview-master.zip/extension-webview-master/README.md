[![Actions Status Alpha](https://github.com/defold/extension-webview/actions/workflows/bob.yml/badge.svg)](https://github.com/defold/extension-webview/actions)

# Defold webview extension

## Installation
To use this library in your Defold project, add the following URL to your `game.project` dependencies:

https://github.com/defold/extension-webview/archive/master.zip

We recommend using a link to a zip file of a [specific release](https://github.com/defold/extension-webview/releases).

## Usage
Full documentation: https://www.defold.com/extension-webview

## API reference

https://defold.com/extension-webview/api/
